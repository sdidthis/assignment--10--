package edu.dallascollege.assignment10.entities;

import java.util.List;

public record AstroResponse(int number, String message, List<Astronaut> people) {
}

