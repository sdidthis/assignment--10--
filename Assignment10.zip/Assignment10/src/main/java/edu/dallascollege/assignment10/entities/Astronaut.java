package edu.dallascollege.assignment10.entities;

public record Astronaut(String name, String craft) {
}

